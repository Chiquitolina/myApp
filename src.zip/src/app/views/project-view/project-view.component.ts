import { Component, Output, EventEmitter, inject } from '@angular/core';
import { MenuComponent } from '../../core/components/menu/menu.component';
import { ProjectsService } from '../../core/services/projects/projects.service';
import { Observable } from 'rxjs';
import { Project } from '../../core/interfaces/projects';
import { TranslateModule } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { TechnologiesComponent } from '../../components/technologies/technologies.component';
import {UrlHealthMonitorComponent} from 'url-health-monitor'

@Component({
  selector: 'app-project-view',
  standalone: true,
  imports: [MenuComponent, TranslateModule, CommonModule, TechnologiesComponent, UrlHealthMonitorComponent],
  templateUrl: './project-view.component.html',
  styleUrl: './project-view.component.scss'
})
export class ProjectViewComponent {
  
  @Output() notifyApp = new EventEmitter<void>(); // Define un EventEmitter para emitir eventos al componente padre

  selectedProject$: Observable<Project | null>;

  project!: Project
  showDetails : boolean = true;

  private projectServ = inject(ProjectsService)

    constructor() {
      this.selectedProject$ = this.projectServ.selectedProject$;  // Asigna el observable
    }

  ngOnInit(): void {
    this.selectedProject$.subscribe(project => {
      if (project) {
        this.project = project
      }
    });
  }

  handleMenuButtonClick() {
    console.log('Menu button clicked in ProjectView');
    this.notifyApp.emit(); // Emite el evento hacia el componente padre
  }

}
